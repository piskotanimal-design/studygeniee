# StudyGenie: setup and release checklist

## 1. Create the project shell and drop in the code
```bash
flutter create studygenie --org com.studygenie --platforms android
cd studygenie
# copy from this zip, overwriting: lib/, pubspec.yaml, android/app/src/main/AndroidManifest.xml
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # generates the Isar *.g.dart files
```

## 2. Android Gradle edits (android/app/build.gradle or build.gradle.kts)
- `minSdk = 23` (flutter_secure_storage needs 23+)
- Enable desugaring (flutter_local_notifications):
  - in `compileOptions`: `isCoreLibraryDesugaringEnabled = true` (Kotlin DSL) / `coreLibraryDesugaringEnabled true` (Groovy)
  - in `dependencies`: `coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")`

## 3. Known gotchas
- **Isar 3 + newer Android Gradle Plugin** can fail with "Namespace not specified" for `isar_flutter_libs`.
  Fix: add `namespace "dev.isar.isar_flutter_libs"` to that package's `android/build.gradle` in your pub cache,
  or switch to a maintained fork such as `isar_community` (same API, change the three Isar package names).
- **Model IDs** are in `lib/core/constants.dart`. Confirm `gemini-3.8-flash`, `llama-3.3-70b` and the SambaNova
  model exist in each provider's console; change them there if not. A wrong ID just makes that provider fail
  and the app falls through to the next one.
- **Syncfusion PDF** needs a (free) community license for individuals/small teams. Check their terms.
- Long documents are trimmed to 12,000 characters (`Limits.maxInputChars`) to fit free-tier token limits.

## 4. Run
`flutter run`, then open Settings, paste at least one API key, tap Test.

## 5. Release APK
1. Make a keystore: `keytool -genkey -v -keystore ~/studygenie.jks -keyalg RSA -keysize 2048 -validity 10000 -alias studygenie`
2. Create `android/key.properties` (storePassword, keyPassword, keyAlias=studygenie, storeFile=/path/studygenie.jks). Never commit it.
3. Wire `signingConfigs.release` in `android/app/build.gradle` to read key.properties, and use it in `buildTypes.release`.
4. Set app icon (`flutter_launcher_icons` optional) and bump `version:` in pubspec.yaml.
5. `flutter build apk --release --split-per-abi` (APKs in `build/app/outputs/flutter-apk/`)
   or `flutter build appbundle --release` for Play Store.
6. Test on a real device: upload each file type, generate with each key, kill the app and reopen offline,
   schedule a reminder, reboot the phone and confirm the reminder still fires.
7. Back up the keystore. Losing it means you cannot update the app.
