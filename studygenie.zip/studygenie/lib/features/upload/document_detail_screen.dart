import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';

import '../../core/errors.dart';
import '../../core/nav.dart';
import '../../data/isar_service.dart';
import '../../data/models/document.dart';
import '../../data/models/flashcard.dart';
import '../../data/models/study_material_entry.dart';
import '../../providers/providers.dart';
import '../flashcards/flashcards_screen.dart';
import '../qa_review/qa_review_screen.dart';
import '../quiz/quiz_screen.dart';

class DocumentDetailScreen extends ConsumerStatefulWidget {
  final int documentId;
  final bool autoGenerate;
  const DocumentDetailScreen(
      {super.key, required this.documentId, this.autoGenerate = false});

  @override
  ConsumerState<DocumentDetailScreen> createState() => _DocumentDetailScreenState();
}

class _DocumentDetailScreenState extends ConsumerState<DocumentDetailScreen> {
  Document? _doc;
  StudyMaterialEntry? _entry;
  int _cards = 0;
  bool _loading = true;
  bool _generating = false;
  String _provider = '';
  String _difficulty = 'medium';

  @override
  void initState() {
    super.initState();
    _load().then((_) {
      if (widget.autoGenerate && _entry == null) _generate();
    });
  }

  Future<void> _load() async {
    final isar = ref.read(isarProvider);
    final doc = await isar.documents.get(widget.documentId);
    final entry = await isar.latestMaterial(widget.documentId);
    
    // THE BULLETPROOF FIX:
    final allCards = await isar.flashcards.where().findAll();
    final cards = allCards.where((c) => c.documentId == widget.documentId).length;

    if (!mounted) return;
    setState(() {
      _doc = doc;
      _entry = entry;
      _cards = cards;
      _loading = false;
    });
  }

  Future<void> _generate() async {
    final doc = _doc;
    if (doc == null) return;
    setState(() {
      _generating = true;
      _provider = '...';
    });
    try {
      final result = await ref.read(fallbackProvider).generate(
            doc.rawText,
            difficulty: _difficulty,
            onAttempt: (n) {
              if (mounted) setState(() => _provider = n);
            },
            onSwitch: (m) => Fluttertoast.showToast(msg: m, toastLength: Toast.LENGTH_LONG),
          );
      await ref.read(isarProvider).saveGeneration(doc, result.material, result.providerName);
      await _load();
    } on AiException catch (e) {
      if (mounted) _showError(e);
    } catch (_) {
      if (mounted) {
        _showError(const AiException(
            AiFailure.other, 'Something unexpected went wrong. Please try again.'));
      }
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  void _showError(AiException e) {
    final title = switch (e.kind) {
      AiFailure.noKeys => 'No API key yet',
      AiFailure.quota || AiFailure.limit => 'Quota reached',
      AiFailure.network => 'No internet',
      AiFailure.badInput => 'Not enough text',
      AiFailure.allFailed => 'All providers failed',
      _ => 'Generation failed',
    };
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(e.message),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final doc = _doc;
    return Scaffold(
      appBar: AppBar(title: Text(doc?.title ?? 'Document')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _generating
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text('Generating with $_provider...'),
                    ],
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (_entry != null) ...[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Summary',
                                  style: Theme.of(context).textTheme.titleMedium),
                              const SizedBox(height: 8),
                              Text(_entry!.summary.isEmpty
                                  ? 'No summary was returned.'
                                  : _entry!.summary),
                              const SizedBox(height: 8),
                              Text(
                                  'Made with ${_entry!.providerUsed} on ${DateFormat.yMMMd().format(_entry!.generatedAt)}',
                                  style: Theme.of(context).textTheme.bodySmall),
                            ],
                          ),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.style),
                          title: const Text('Flashcards'),
                          subtitle: Text('$_cards cards'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: _cards == 0
                              ? null
                              : () => pushAndRefresh(context, ref,
                                  FlashcardsScreen(documentId: doc!.id)),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.quiz),
                          title: const Text('Quiz'),
                          subtitle: Text('${_entry!.mcqs.length} questions'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: _entry!.mcqs.isEmpty
                              ? null
                              : () => pushAndRefresh(
                                  context, ref, QuizScreen(documentId: doc!.id)),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.question_answer),
                          title: const Text('Q&A review'),
                          subtitle: Text('${_entry!.qaPairs.length} questions'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: _entry!.qaPairs.isEmpty
                              ? null
                              : () => pushAndRefresh(
                                  context, ref, QaReviewScreen(documentId: doc!.id)),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ] else
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Text(
                          'No study material yet. Generate it to get a summary, flashcards, Q&A and a quiz.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    Text('Difficulty', style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 8),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'easy', label: Text('Easy')),
                        ButtonSegment(value: 'medium', label: Text('Medium')),
                        ButtonSegment(value: 'hard', label: Text('Hard')),
                      ],
                      selected: {_difficulty},
                      onSelectionChanged: (s) => setState(() => _difficulty = s.first),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _generate,
                      icon: const Icon(Icons.auto_awesome),
                      label: Text(_entry == null
                          ? 'Generate Study Material'
                          : 'Generate again'),
                    ),
                    if (_entry != null)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: Text(
                            'Generating again adds new flashcards. Your existing cards and progress are kept.',
                            textAlign: TextAlign.center),
                      ),
                  ],
                ),
    );
  }
}