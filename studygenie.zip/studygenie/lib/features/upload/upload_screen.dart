import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/errors.dart';
import '../../data/models/document.dart';
import '../../providers/providers.dart';
import '../../services/file_extraction_service.dart';
import 'document_detail_screen.dart';

class UploadScreen extends ConsumerStatefulWidget {
  const UploadScreen({super.key});

  @override
  ConsumerState<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends ConsumerState<UploadScreen> {
  final _title = TextEditingController();
  final _subject = TextEditingController();
  final _text = TextEditingController();

  bool _extracting = false;
  double _progress = 0;
  bool _hasText = false; // show the editor once we have a file or manual mode
  String _filePath = '';
  String? _error;

  @override
  void dispose() {
    _title.dispose();
    _subject.dispose();
    _text.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: FileExtractionService.supported,
    );
    final src = picked?.files.single.path;
    if (src == null) return;

    setState(() {
      _extracting = true;
      _progress = 0;
      _error = null;
    });

    try {
      // Copy into app-private storage.
      final docsDir = await getApplicationDocumentsDirectory();
      final dir = Directory(p.join(docsDir.path, 'documents'))
        ..createSync(recursive: true);
      final name = p.basename(src);
      final dest = p.join(dir.path, '${DateTime.now().millisecondsSinceEpoch}_$name');
      await File(src).copy(dest);
      _filePath = dest;
      _title.text = p.basenameWithoutExtension(name);

      final text = await ref.read(extractionProvider).extract(
            dest,
            onProgress: (v) {
              if (mounted) setState(() => _progress = v);
            },
          );
      _text.text = text;
    } on ExtractionException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Something went wrong while opening that file.';
    }

    if (!mounted) return;
    setState(() {
      _extracting = false;
      _hasText = true;
    });
  }

  void _manual() => setState(() {
        _hasText = true;
        _error = null;
      });

  Future<void> _save({required bool generate}) async {
    final text = _text.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Add some text first.')));
      return;
    }
    final doc = Document()
      ..title = _title.text.trim().isEmpty ? 'Untitled' : _title.text.trim()
      ..subject = _subject.text.trim()
      ..rawText = text
      ..filePath = _filePath
      ..createdAt = DateTime.now();

    final isar = ref.read(isarProvider);
    final id = await isar.writeTxn(() => isar.documents.put(doc));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => DocumentDetailScreen(documentId: id, autoGenerate: generate)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add study material')),
      body: _extracting
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Reading your file on this device...'),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(value: _progress == 0 ? null : _progress),
                  ],
                ),
              ),
            )
          : !_hasText
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.upload_file, size: 72),
                        const SizedBox(height: 12),
                        const Text(
                            'PDF, DOCX, PPTX, TXT, PNG or JPG.\nYour file stays on this phone.',
                            textAlign: TextAlign.center),
                        const SizedBox(height: 20),
                        FilledButton.icon(
                            onPressed: _pick,
                            icon: const Icon(Icons.folder_open),
                            label: const Text('Choose a file')),
                        TextButton(
                            onPressed: _manual,
                            child: const Text('Or paste text instead')),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (_error != null)
                      Card(
                        color: Theme.of(context).colorScheme.errorContainer,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(_error!),
                        ),
                      ),
                    TextField(
                        controller: _title,
                        decoration: const InputDecoration(
                            labelText: 'Title', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(
                        controller: _subject,
                        decoration: const InputDecoration(
                            labelText: 'Subject (optional)',
                            border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    const Text('Extracted text (fix any mistakes before generating):'),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _text,
                      minLines: 10,
                      maxLines: null,
                      decoration: const InputDecoration(border: OutlineInputBorder()),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                        onPressed: () => _save(generate: true),
                        icon: const Icon(Icons.auto_awesome),
                        label: const Text('Save & Generate')),
                    const SizedBox(height: 8),
                    OutlinedButton(
                        onPressed: () => _save(generate: false),
                        child: const Text('Save only')),
                  ],
                ),
    );
  }
}
