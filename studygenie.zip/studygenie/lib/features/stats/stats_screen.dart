import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../providers/providers.dart';

class StatsScreen extends ConsumerWidget {
  const StatsScreen({super.key});

  Widget _tile(BuildContext context, IconData icon, String value, String label) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Icon(icon),
              const SizedBox(height: 6),
              Text(value, style: Theme.of(context).textTheme.titleLarge),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(statsProvider);
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(title: const Text('Stats')),
      body: stats.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Could not load stats: $e')),
        data: (s) {
          final maxMin = s.minutes30.fold<double>(0, math.max);
          final today = DateTime.now();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(children: [
                _tile(context, Icons.local_fire_department, '${s.streak}', 'day streak'),
                _tile(context, Icons.style, '${s.totalCards}', 'cards reviewed'),
                _tile(context, Icons.check_circle_outline,
                    s.accuracy == null ? '--' : '${(s.accuracy! * 100).round()}%', 'quiz accuracy'),
              ]),
              const SizedBox(height: 16),
              Text('Study minutes, last 30 days',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              SizedBox(
                height: 200,
                child: LineChart(LineChartData(
                  minY: 0,
                  maxY: math.max(10, maxMin * 1.2),
                  gridData: const FlGridData(drawVerticalLine: false),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    leftTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: true, reservedSize: 32)),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        interval: 7,
                        reservedSize: 28,
                        getTitlesWidget: (v, meta) {
                          final d = DateTime(today.year, today.month,
                              today.day - (29 - v.toInt()));
                          return Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(DateFormat('d/M').format(d),
                                style: const TextStyle(fontSize: 10)),
                          );
                        },
                      ),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [
                        for (var i = 0; i < s.minutes30.length; i++)
                          FlSpot(i.toDouble(), s.minutes30[i]),
                      ],
                      isCurved: true,
                      color: primary,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                      belowBarData:
                          BarAreaData(show: true, color: primary.withValues(alpha: 0.15)),
                    ),
                  ],
                )),
              ),
              const SizedBox(height: 20),
              Text('Per document', style: Theme.of(context).textTheme.titleMedium),
              if (s.docs.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Nothing here yet. Upload a document to begin.'),
                ),
              for (final d in s.docs)
                Card(
                  child: ListTile(
                    title: Text(d.doc.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                        '${d.cards} cards · ${d.mastered} mastered · ${d.doc.qaCount} Q&As\nQuiz accuracy: ${d.quizAccuracy == null ? '--' : '${(d.quizAccuracy! * 100).round()}%'}'),
                    isThreeLine: true,
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
