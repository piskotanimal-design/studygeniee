import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/isar_service.dart';
import '../../data/models/quiz_result.dart';
import '../../data/models/study_material_entry.dart';
import '../../providers/providers.dart';

class _Wrong {
  final Mcq q;
  final int chosen;
  _Wrong(this.q, this.chosen);
}

class QuizScreen extends ConsumerStatefulWidget {
  final int documentId;
  const QuizScreen({super.key, required this.documentId});

  @override
  ConsumerState<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends ConsumerState<QuizScreen> {
  List<Mcq> _qs = [];
  final _wrong = <_Wrong>[];
  int _i = 0;
  int _score = 0;
  int? _selected;
  bool _loading = true;
  bool _done = false;
  late DateTime _startedAt;
  Stopwatch _sw = Stopwatch();

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final entry = await ref.read(isarProvider).latestMaterial(widget.documentId);
    if (!mounted) return;
    setState(() {
      _qs = List.of(entry?.mcqs ?? [])..shuffle();
      _i = 0;
      _score = 0;
      _selected = null;
      _done = false;
      _wrong.clear();
      _loading = false;
      _startedAt = DateTime.now();
      _sw = Stopwatch()..start();
    });
  }

  void _answer(int index) {
    if (_selected != null) return;
    final q = _qs[_i];
    setState(() {
      _selected = index;
      if (index == q.correctIndex) {
        _score++;
      } else {
        _wrong.add(_Wrong(q, index));
      }
    });
  }

  Future<void> _next() async {
    if (_i + 1 < _qs.length) {
      setState(() {
        _i++;
        _selected = null;
      });
      return;
    }
    // Finished: save result + log session.
    final isar = ref.read(isarProvider);
    await isar.writeTxn(() => isar.quizResults.put(QuizResult()
      ..documentId = widget.documentId
      ..correct = _score
      ..total = _qs.length
      ..takenAt = DateTime.now()));
    await isar.logSession(startedAt: _startedAt, elapsed: _sw.elapsed, quizzes: 1);
    if (mounted) setState(() => _done = true);
  }

  Color? _optionColor(int idx) {
    if (_selected == null) return null;
    final correct = _qs[_i].correctIndex;
    if (idx == correct) return Colors.green.withValues(alpha: 0.25);
    if (idx == _selected) return Colors.red.withValues(alpha: 0.25);
    return null;
  }

  Widget _results() {
    final pct = _qs.isEmpty ? 0 : (_score / _qs.length * 100).round();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Icon(pct >= 70 ? Icons.emoji_events : Icons.menu_book, size: 72),
        const SizedBox(height: 8),
        Text('$_score / ${_qs.length}  ($pct%)',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 16),
        if (_wrong.isNotEmpty) ...[
          Text('Review your mistakes',
              style: Theme.of(context).textTheme.titleMedium),
          for (final w in _wrong)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(w.q.question,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    Text('Your answer: ${w.q.options[w.chosen]}',
                        style: const TextStyle(color: Colors.red)),
                    Text('Correct: ${w.q.options[w.q.correctIndex]}',
                        style: const TextStyle(color: Colors.green)),
                    if (w.q.explanation.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(w.q.explanation),
                    ],
                  ],
                ),
              ),
            ),
        ] else
          const Text('Perfect score! No mistakes to review.',
              textAlign: TextAlign.center),
        const SizedBox(height: 16),
        FilledButton(onPressed: _start, child: const Text('Try again')),
        TextButton(
            onPressed: () => Navigator.pop(context), child: const Text('Done')),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
          appBar: AppBar(title: const Text('Quiz')),
          body: const Center(child: CircularProgressIndicator()));
    }
    if (_qs.isEmpty) {
      return Scaffold(
          appBar: AppBar(title: const Text('Quiz')),
          body: const Center(child: Text('No quiz questions for this document.')));
    }
    if (_done) {
      return Scaffold(appBar: AppBar(title: const Text('Quiz results')), body: _results());
    }

    final q = _qs[_i];
    return Scaffold(
      appBar: AppBar(
        title: Text('Question ${_i + 1} of ${_qs.length}'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: Text('Score $_score')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LinearProgressIndicator(value: (_i + 1) / _qs.length),
          const SizedBox(height: 20),
          Text(q.question, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          for (var idx = 0; idx < q.options.length; idx++)
            Card(
              color: _optionColor(idx),
              child: ListTile(
                leading: CircleAvatar(
                    radius: 14, child: Text(String.fromCharCode(65 + idx))),
                title: Text(q.options[idx]),
                trailing: _selected == null
                    ? null
                    : idx == q.correctIndex
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : idx == _selected
                            ? const Icon(Icons.cancel, color: Colors.red)
                            : null,
                onTap: () => _answer(idx),
              ),
            ),
          if (_selected != null) ...[
            if (q.explanation.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(q.explanation),
                ),
              ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _next,
              child: Text(_i + 1 < _qs.length ? 'Next' : 'Finish'),
            ),
          ],
        ],
      ),
    );
  }
}
