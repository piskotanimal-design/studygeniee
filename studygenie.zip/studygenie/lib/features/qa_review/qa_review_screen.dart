import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/isar_service.dart';
import '../../data/models/study_material_entry.dart';
import '../../providers/providers.dart';

class QaReviewScreen extends ConsumerStatefulWidget {
  final int documentId;
  const QaReviewScreen({super.key, required this.documentId});

  @override
  ConsumerState<QaReviewScreen> createState() => _QaReviewScreenState();
}

class _QaReviewScreenState extends ConsumerState<QaReviewScreen> {
  List<QaPair> _all = [];
  String _filter = 'all';
  String _query = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    ref.read(isarProvider).latestMaterial(widget.documentId).then((e) {
      if (!mounted) return;
      setState(() {
        _all = e?.qaPairs ?? [];
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.toLowerCase();
    final shown = _all.where((p) {
      final okDiff = _filter == 'all' || p.difficulty == _filter;
      final okQuery = q.isEmpty ||
          p.question.toLowerCase().contains(q) ||
          p.answer.toLowerCase().contains(q);
      return okDiff && okQuery;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Q&A review')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'Search questions and answers',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (v) => setState(() => _query = v),
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      for (final f in const ['all', 'easy', 'medium', 'hard'])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(f[0].toUpperCase() + f.substring(1)),
                            selected: _filter == f,
                            onSelected: (_) => setState(() => _filter = f),
                          ),
                        ),
                    ],
                  ),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const Center(child: Text('No matching questions.'))
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: shown.length,
                          itemBuilder: (_, i) {
                            final p = shown[i];
                            return Card(
                              child: ExpansionTile(
                                title: Text(p.question),
                                subtitle: Text(p.difficulty),
                                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                                expandedCrossAxisAlignment: CrossAxisAlignment.start,
                                children: [Text(p.answer)],
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
