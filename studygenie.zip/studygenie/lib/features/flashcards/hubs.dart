import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/nav.dart';
import '../../providers/providers.dart';
import '../quiz/quiz_screen.dart';
import 'flashcards_screen.dart';

class FlashcardsHub extends ConsumerWidget {
  const FlashcardsHub({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final docs = ref.watch(documentsProvider);
    final counts = ref.watch(docCountsProvider).valueOrNull ?? const {};

    return Scaffold(
      appBar: AppBar(title: const Text('Flashcards')),
      body: docs.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (list) {
          if (list.isEmpty) {
            return const Center(child: Text('Upload a document to get flashcards.'));
          }
          final totalDue = counts.values.fold<int>(0, (a, c) => a + c.due);
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: ListTile(
                  leading: const Icon(Icons.style),
                  title: const Text('Review all due cards'),
                  subtitle: Text('$totalDue due'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: totalDue == 0
                      ? null
                      : () => pushAndRefresh(context, ref, const FlashcardsScreen()),
                ),
              ),
              for (final d in list)
                Card(
                  child: ListTile(
                    title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                        '${counts[d.id]?.due ?? 0} due · ${counts[d.id]?.total ?? 0} cards'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: (counts[d.id]?.due ?? 0) == 0
                        ? null
                        : () => pushAndRefresh(
                            context, ref, FlashcardsScreen(documentId: d.id)),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class QuizzesHub extends ConsumerWidget {
  const QuizzesHub({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final docs = ref.watch(documentsProvider);
    final counts = ref.watch(docCountsProvider).valueOrNull ?? const {};

    return Scaffold(
      appBar: AppBar(title: const Text('Quizzes')),
      body: docs.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (list) {
          final quizzable = list.where((d) => (counts[d.id]?.mcqs ?? 0) > 0).toList();
          if (quizzable.isEmpty) {
            return const Center(
                child: Padding(
              padding: EdgeInsets.all(32),
              child: Text(
                  'No quizzes yet. Open a document and tap Generate Study Material.',
                  textAlign: TextAlign.center),
            ));
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              for (final d in quizzable)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.quiz),
                    title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${counts[d.id]!.mcqs} questions'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () =>
                        pushAndRefresh(context, ref, QuizScreen(documentId: d.id)),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
