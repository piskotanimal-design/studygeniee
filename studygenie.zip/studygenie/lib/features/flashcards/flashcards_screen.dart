import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:isar/isar.dart';

import '../../data/isar_service.dart';
import '../../data/models/flashcard.dart';
import '../../providers/providers.dart';
import '../../services/sm2_service.dart';

class FlashcardsScreen extends ConsumerStatefulWidget {
  /// null = all due cards across documents.
  final int? documentId;
  const FlashcardsScreen({super.key, this.documentId});

  @override
  ConsumerState<FlashcardsScreen> createState() => _FlashcardsScreenState();
}

class _FlashcardsScreenState extends ConsumerState<FlashcardsScreen>
    with SingleTickerProviderStateMixin {
  late final Isar _isar;
  late final AnimationController _flip;
  final _queue = <Flashcard>[];
  final _sw = Stopwatch()..start();
  final _startedAt = DateTime.now();

  int _i = 0;
  int _reviewed = 0;
  int _good = 0;
  bool _loading = true;
  bool _showBack = false;
  bool _done = false;
  bool _logged = false;

  @override
  void initState() {
    super.initState();
    _isar = ref.read(isarProvider);
    _flip = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    _load();
  }

  Future<void> _load() async {
    final due = await _isar.flashcards
        .filter()
        .nextReviewLessThan(DateTime.now(), include: true)
        .findAll();
    final cards = due
        .where((c) => widget.documentId == null || c.documentId == widget.documentId)
        .toList()
      ..shuffle();
    if (!mounted) return;
    setState(() {
      _queue.addAll(cards);
      _loading = false;
      _done = cards.isEmpty;
    });
  }

  void _toggle() {
    setState(() => _showBack = !_showBack);
    _showBack ? _flip.forward() : _flip.reverse();
  }

  Future<void> _rate(int quality) async {
    final card = _queue[_i];
    Sm2Service.review(card, quality);
    await _isar.writeTxn(() => _isar.flashcards.put(card));

    _reviewed++;
    if (quality >= Sm2Service.hard) _good++;
    if (quality == Sm2Service.again) _queue.add(card); // see it again this session

    _flip.value = 0;
    if (!mounted) return;
    setState(() {
      _showBack = false;
      _i++;
      if (_i >= _queue.length) _finish();
    });
  }

  void _finish() {
    _done = true;
    _logIfNeeded();
  }

  void _logIfNeeded() {
    if (_logged || _reviewed == 0) return;
    _logged = true;
    _isar.logSession(
        startedAt: _startedAt, elapsed: _sw.elapsed, cards: _reviewed);
  }

  @override
  void dispose() {
    _logIfNeeded(); // user left mid-session
    _flip.dispose();
    super.dispose();
  }

  Widget _face(String text, bool back) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: back ? cs.primaryContainer : cs.surfaceContainerHighest,
      elevation: 3,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(back ? 'ANSWER' : 'QUESTION',
                  style: Theme.of(context).textTheme.labelSmall),
              const SizedBox(height: 12),
              Text(text,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall),
            ],
          ),
        ),
      ),
    );
  }

  Widget _rateButton(String label, int q, Color color) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 14)),
            onPressed: () => _rate(q),
            child: Text(label),
          ),
        ),
      );

  Widget _summary() {
    final secs = _sw.elapsed.inSeconds;
    final acc = _reviewed == 0 ? 0 : (_good / _reviewed * 100).round();
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: _reviewed == 0
            ? Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.celebration, size: 72),
                const SizedBox(height: 12),
                const Text('No cards are due right now. Come back later!'),
                const SizedBox(height: 16),
                FilledButton(
                    onPressed: () => Navigator.pop(context), child: const Text('Back')),
              ])
            : Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.emoji_events, size: 72),
                const SizedBox(height: 12),
                Text('Session complete',
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 16),
                Text('Cards reviewed: $_reviewed'),
                Text('Accuracy: $acc%'),
                Text('Time: ${secs ~/ 60}m ${secs % 60}s'),
                const SizedBox(height: 20),
                FilledButton(
                    onPressed: () => Navigator.pop(context), child: const Text('Done')),
              ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_loading || _done
            ? 'Flashcards'
            : 'Card ${math.min(_i + 1, _queue.length)} of ${_queue.length}'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _done
              ? _summary()
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      LinearProgressIndicator(value: _i / _queue.length),
                      const SizedBox(height: 16),
                      Expanded(
                        child: GestureDetector(
                          onTap: _toggle,
                          onHorizontalDragEnd: (d) {
                            final v = d.primaryVelocity ?? 0;
                            if (v.abs() < 300) return;
                            if (!_showBack) {
                              _toggle();
                            } else {
                              _rate(v > 0 ? Sm2Service.good : Sm2Service.again);
                            }
                          },
                          child: AnimatedBuilder(
                            animation: _flip,
                            builder: (_, __) {
                              final angle = _flip.value * math.pi;
                              final back = angle > math.pi / 2;
                              final card = _queue[_i];
                              return Transform(
                                alignment: Alignment.center,
                                transform: Matrix4.identity()
                                  ..setEntry(3, 2, 0.001)
                                  ..rotateY(angle),
                                child: Transform(
                                  alignment: Alignment.center,
                                  transform: Matrix4.identity()
                                    ..rotateY(back ? math.pi : 0),
                                  child: _face(back ? card.back : card.front, back),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _showBack
                            ? 'Swipe right = Good, left = Again'
                            : 'Tap or swipe to flip',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 52,
                        child: _showBack
                            ? Row(children: [
                                _rateButton('Again', Sm2Service.again, Colors.red.shade600),
                                _rateButton('Hard', Sm2Service.hard, Colors.orange.shade700),
                                _rateButton('Good', Sm2Service.good, Colors.green.shade600),
                                _rateButton('Easy', Sm2Service.easy, Colors.blue.shade600),
                              ])
                            : null,
                      ),
                    ],
                  ),
                ),
    );
  }
}
