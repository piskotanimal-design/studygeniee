import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../ai/fallback_service.dart';
import '../../core/constants.dart';
import '../../core/errors.dart';
import '../../core/permissions.dart';
import '../../providers/providers.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late List<String> _order;

  @override
  void initState() {
    super.initState();
    _order = ref.read(settingsProvider).priority;
  }

  Future<void> _applyReminders() =>
      ref.read(notificationProvider).reschedule(ref.read(settingsProvider));

  Future<void> _toggleReminders(bool on) async {
    final s = ref.read(settingsProvider);
    if (on) {
      final ok = await AppPermissions.ensureNotifications(context);
      if (!ok) return;
    }
    await s.setReminderEnabled(on);
    await _applyReminders();
    if (mounted) setState(() {});
  }

  Future<void> _pickTime() async {
    final s = ref.read(settingsProvider);
    final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: s.reminderHour, minute: s.reminderMinute));
    if (t == null) return;
    await s.setReminderTime(t.hour, t.minute);
    await _applyReminders();
    if (mounted) setState(() {});
  }

  Future<void> _toggleDay(int day, bool on) async {
    final s = ref.read(settingsProvider);
    final days = s.reminderDays..remove(day);
    if (on) days.add(day);
    await s.setReminderDays(days);
    await _applyReminders();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(settingsProvider);
    const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('AI providers', style: Theme.of(context).textTheme.titleMedium),
          const Text(
              'Paste a free key for each provider you want to use. Drag to reorder: the top one is tried first. Keys are stored encrypted on this device only.'),
          const SizedBox(height: 8),
          ReorderableListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            buildDefaultDragHandles: false,
            onReorder: (o, n) {
              if (n > o) n--;
              setState(() => _order.insert(n, _order.removeAt(o)));
              s.setPriority(_order);
            },
            children: [
              for (var i = 0; i < _order.length; i++)
                _KeyTile(key: ValueKey(_order[i]), name: _order[i], index: i),
            ],
          ),
          const Divider(height: 32),
          Text('Daily generation limit (per provider): ${s.dailyLimit}',
              style: Theme.of(context).textTheme.titleMedium),
          Slider(
            min: 1,
            max: 20,
            divisions: 19,
            value: s.dailyLimit.toDouble(),
            label: '${s.dailyLimit}',
            onChanged: (v) async {
              await s.setDailyLimit(v.round());
              setState(() {});
            },
          ),
          const Divider(height: 32),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Study reminders'),
            subtitle: const Text('A gentle nudge on the days and time you pick'),
            value: s.reminderEnabled,
            onChanged: _toggleReminders,
          ),
          if (s.reminderEnabled) ...[
            Wrap(
              spacing: 6,
              children: [
                for (var d = 1; d <= 7; d++)
                  FilterChip(
                    label: Text(dayLabels[d - 1]),
                    selected: s.reminderDays.contains(d),
                    onSelected: (v) => _toggleDay(d, v),
                  ),
              ],
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.schedule),
              title: Text(TimeOfDay(hour: s.reminderHour, minute: s.reminderMinute)
                  .format(context)),
              subtitle: const Text('Reminder time'),
              onTap: _pickTime,
            ),
          ],
          const SizedBox(height: 24),
          const Text(
              'StudyGenie has no accounts, ads or analytics. Your files stay on this phone until you tap Generate.',
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _KeyTile extends ConsumerStatefulWidget {
  final String name;
  final int index;
  const _KeyTile({super.key, required this.name, required this.index});

  @override
  ConsumerState<_KeyTile> createState() => _KeyTileState();
}

class _KeyTileState extends ConsumerState<_KeyTile> {
  final _c = TextEditingController();
  bool _hide = true;
  bool _saved = false;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    ref.read(keyStoreProvider).read(widget.name).then((v) {
      if (!mounted || v == null) return;
      setState(() {
        _c.text = v;
        _saved = true;
      });
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _save() async {
    final key = _c.text.trim();
    final store = ref.read(keyStoreProvider);
    if (key.isEmpty) {
      await store.delete(widget.name);
      setState(() => _saved = false);
      _msg('${widget.name} key removed');
      return;
    }
    final prefix = Providers.keyPrefix[widget.name];
    if (prefix != null && !key.startsWith(prefix)) {
      _msg('${widget.name} keys start with "$prefix". Check what you pasted.');
      return;
    }
    await store.write(widget.name, key);
    setState(() => _saved = true);
    _msg('${widget.name} key saved');
  }

  Future<void> _test() async {
    final key = _c.text.trim();
    if (key.isEmpty) {
      _msg('Paste a key first');
      return;
    }
    setState(() => _testing = true);
    try {
      await buildProvider(widget.name, key).testKey();
      _msg('${widget.name} key works');
    } on AiException catch (e) {
      _msg(e.message);
    } catch (_) {
      _msg('Could not test the key. Check your internet.');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final prefix = Providers.keyPrefix[widget.name];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                ReorderableDragStartListener(
                    index: widget.index, child: const Icon(Icons.drag_handle)),
                const SizedBox(width: 8),
                Text('${widget.index + 1}. ${widget.name}',
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                const Spacer(),
                if (_saved) const Icon(Icons.check_circle, color: Colors.green, size: 20),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _c,
              obscureText: _hide,
              autocorrect: false,
              enableSuggestions: false,
              decoration: InputDecoration(
                hintText: prefix == null ? 'API key' : 'API key ($prefix...)',
                isDense: true,
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            ),
            Row(
              children: [
                TextButton(
                  onPressed: () => launchUrl(Uri.parse(Providers.siteUrl[widget.name]!),
                      mode: LaunchMode.externalApplication),
                  child: const Text('Get key'),
                ),
                const Spacer(),
                TextButton(onPressed: _save, child: const Text('Save')),
                FilledButton.tonal(
                  onPressed: _testing ? null : _test,
                  child: _testing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Test'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
