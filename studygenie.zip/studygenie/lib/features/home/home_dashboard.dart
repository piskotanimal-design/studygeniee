import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/nav.dart';
import '../../data/isar_service.dart';
import '../../providers/providers.dart';
import '../upload/document_detail_screen.dart';
import '../upload/upload_screen.dart';

class HomeDashboard extends ConsumerWidget {
  const HomeDashboard({super.key});

  Future<bool> _confirmDelete(BuildContext context, String title) async {
    return await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('Delete document?'),
            content: Text(
                '"$title" and all its flashcards, quizzes and results will be removed from this device.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(c, false),
                  child: const Text('Cancel')),
              FilledButton(
                  onPressed: () => Navigator.pop(c, true),
                  child: const Text('Delete')),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final docs = ref.watch(documentsProvider);
    final stats = ref.watch(statsProvider).valueOrNull;
    final due = ref.watch(dueCountProvider).valueOrNull ?? 0;

    return Scaffold(
      appBar: AppBar(title: const Text('StudyGenie')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => pushAndRefresh(context, ref, const UploadScreen()),
        icon: const Icon(Icons.upload_file),
        label: const Text('Upload New File'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Wrap(
              spacing: 8,
              children: [
                Chip(
                    avatar: const Icon(Icons.local_fire_department, size: 18),
                    label: Text('${stats?.streak ?? 0}-day streak')),
                Chip(
                    avatar: const Icon(Icons.style, size: 18),
                    label: Text('$due cards due')),
                Chip(
                    avatar: const Icon(Icons.check_circle_outline, size: 18),
                    label: Text(stats?.accuracy == null
                        ? 'Quiz: --'
                        : 'Quiz ${(stats!.accuracy! * 100).round()}%')),
              ],
            ),
          ),
          Expanded(
            child: docs.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Could not load documents: $e')),
              data: (list) {
                if (list.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text(
                        'No documents yet.\nTap "Upload New File" to start studying.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                  itemCount: list.length,
                  itemBuilder: (context, i) {
                    final d = list[i];
                    return Dismissible(
                      key: ValueKey(d.id),
                      direction: DismissDirection.endToStart,
                      confirmDismiss: (_) => _confirmDelete(context, d.title),
                      onDismissed: (_) async {
                        await ref.read(isarProvider).deleteDocumentCascade(d.id);
                        ref.invalidate(statsProvider);
                      },
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      child: Card(
                        child: ListTile(
                          leading: const Icon(Icons.description_outlined),
                          title: Text(d.title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                              '${d.subject.isEmpty ? 'No subject' : d.subject} · ${DateFormat.yMMMd().format(d.createdAt)} · ${d.qaCount} Q&As'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => pushAndRefresh(context, ref,
                              DocumentDetailScreen(documentId: d.id)),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
