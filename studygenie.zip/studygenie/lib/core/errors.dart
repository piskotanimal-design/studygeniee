enum AiFailure {
  quota,
  limit,
  network,
  badKey,
  badResponse,
  badInput,
  noKeys,
  allFailed,
  other,
}

class AiException implements Exception {
  final AiFailure kind;
  final String message;
  const AiException(this.kind, this.message);

  /// Short phrase used in the "Switched to X due to ..." toast.
  String get shortReason => switch (kind) {
        AiFailure.quota => 'quota exceeded',
        AiFailure.limit => 'daily limit reached',
        AiFailure.network => 'a network problem',
        AiFailure.badKey => 'an invalid API key',
        AiFailure.badResponse => 'an unreadable response',
        _ => 'an error',
      };

  @override
  String toString() => message;
}

class ExtractionException implements Exception {
  final String message;
  const ExtractionException(this.message);
  @override
  String toString() => message;
}
