class Providers {
  static const gemini = 'Gemini';
  static const cerebras = 'Cerebras';
  static const groq = 'Groq';
  static const sambanova = 'SambaNova';
  static const openrouter = 'OpenRouter';

  /// Default fallback order.
  static const defaultOrder = [gemini, cerebras, groq, sambanova, openrouter];

  /// Only some providers have a recognisable key prefix.
  static const keyPrefix = {
    gemini: 'AIza',
    groq: 'gsk_',
    openrouter: 'sk-or-',
  };

  static const siteUrl = {
    gemini: 'https://aistudio.google.com',
    cerebras: 'https://cerebras.ai',
    groq: 'https://console.groq.com',
    sambanova: 'https://cloud.sambanova.ai',
    openrouter: 'https://openrouter.ai',
  };
}

/// Model IDs live here so you can change them in one place if a provider
/// renames or retires a model.
class ModelNames {
  static const gemini = 'gemini-3.8-flash';
  static const groq = 'openai/gpt-oss-120b';
  static const cerebras = 'llama-3.3-70b';
  static const sambanova = 'Meta-Llama-3.3-70B-Instruct';
  static const openrouter = 'openrouter/free';
}

class Limits {
  /// Free tiers have small token budgets, so long documents are trimmed.
  static const maxInputChars = 12000;
  static const minInputChars = 50;
}
