import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

/// File picking uses Android's system picker (no storage permission needed).
/// Notifications need a runtime permission on Android 13+.
class AppPermissions {
  static Future<bool> ensureNotifications(BuildContext context) async {
    var status = await Permission.notification.status;
    if (status.isGranted) return true;
    if (!context.mounted) return false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Allow notifications?'),
        content: const Text(
            'StudyGenie only uses notifications to remind you to study on the days and time you choose.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Not now')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Continue')),
        ],
      ),
    );
    if (ok != true) return false;

    status = await Permission.notification.request();
    if (status.isPermanentlyDenied && context.mounted) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Notifications are off'),
          content: const Text(
              'Turn notifications on for StudyGenie in your phone settings to get reminders.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
            FilledButton(
                onPressed: () {
                  openAppSettings();
                  Navigator.pop(c);
                },
                child: const Text('Open settings')),
          ],
        ),
      );
    }
    return status.isGranted;
  }
}
