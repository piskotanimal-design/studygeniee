import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';

/// Pushes a page, then refreshes dashboard-style data when we come back.
Future<T?> pushAndRefresh<T>(
    BuildContext context, WidgetRef ref, Widget page) async {
  final result = await Navigator.of(context)
      .push<T>(MaterialPageRoute(builder: (_) => page));
  ref.invalidate(statsProvider);
  ref.invalidate(docCountsProvider);
  return result;
}
