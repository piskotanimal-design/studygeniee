import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'data/isar_service.dart';
import 'data/settings_store.dart';
import 'providers/providers.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final isar = await IsarService.open();
  final prefs = await SharedPreferences.getInstance();
  final notifications = NotificationService();
  await notifications.init();
  // Re-apply reminders on every launch (cheap, keeps them in sync).
  await notifications.reschedule(SettingsStore(prefs));

  runApp(ProviderScope(
    overrides: [
      isarProvider.overrideWithValue(isar),
      prefsProvider.overrideWithValue(prefs),
      notificationProvider.overrideWithValue(notifications),
    ],
    child: const StudyGenieApp(),
  ));
}
