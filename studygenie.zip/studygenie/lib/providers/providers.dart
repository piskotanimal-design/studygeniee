import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:isar/isar.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../ai/fallback_service.dart';
import '../data/models/document.dart';
import '../data/models/flashcard.dart';
import '../data/models/quiz_result.dart';
import '../data/models/study_material_entry.dart';
import '../data/models/study_session.dart';
import '../data/secure_key_store.dart';
import '../data/settings_store.dart';
import '../services/file_extraction_service.dart';
import '../services/notification_service.dart';
import '../services/usage_counter_service.dart';

// ---- Overridden in main() ----
final isarProvider = Provider<Isar>((ref) => throw UnimplementedError());
final prefsProvider =
    Provider<SharedPreferences>((ref) => throw UnimplementedError());
final notificationProvider =
    Provider<NotificationService>((ref) => throw UnimplementedError());

// ---- Services ----
final settingsProvider =
    Provider<SettingsStore>((ref) => SettingsStore(ref.watch(prefsProvider)));
final keyStoreProvider = Provider<SecureKeyStore>((ref) => SecureKeyStore());
final usageProvider = Provider<UsageCounterService>(
    (ref) => UsageCounterService(ref.watch(isarProvider)));
final extractionProvider =
    Provider<FileExtractionService>((ref) => FileExtractionService());
final fallbackProvider = Provider<FallbackService>((ref) => FallbackService(
      ref.watch(keyStoreProvider),
      ref.watch(settingsProvider),
      ref.watch(usageProvider),
    ));

// ---- Live data ----
final documentsProvider = StreamProvider<List<Document>>((ref) {
  return ref
      .watch(isarProvider)
      .documents
      .where()
      .sortByCreatedAtDesc()
      .watch(fireImmediately: true);
});

final dueCountProvider = StreamProvider<int>((ref) async* {
  final isar = ref.watch(isarProvider);
  await for (final _ in isar.flashcards.watchLazy(fireImmediately: true)) {
    yield await isar.flashcards
        .filter()
        .nextReviewLessThan(DateTime.now(), include: true)
        .count();
  }
});

class DocCounts {
  final int due, total, mcqs;
  const DocCounts(this.due, this.total, this.mcqs);
}

final docCountsProvider =
    FutureProvider.autoDispose<Map<int, DocCounts>>((ref) async {
  final isar = ref.watch(isarProvider);
  final now = DateTime.now();
  final out = <int, DocCounts>{};
  for (final d in await isar.documents.where().findAll()) {
    final total =
        await isar.flashcards.filter().documentIdEqualTo(d.id).count();
    final due = await isar.flashcards
        .filter()
        .documentIdEqualTo(d.id)
        .and()
        .nextReviewLessThan(now, include: true)
        .count();
    final entry = await isar.materials
        .filter()
        .documentIdEqualTo(d.id)
        .sortByGeneratedAtDesc()
        .findFirst();
    out[d.id] = DocCounts(due, total, entry?.mcqs.length ?? 0);
  }
  return out;
});

// ---- Stats ----
class DocStat {
  final Document doc;
  final int cards;
  final int mastered;
  final double? quizAccuracy;
  const DocStat(this.doc, this.cards, this.mastered, this.quizAccuracy);
}

class StatsData {
  final int streak;
  final int totalCards;
  final double? accuracy; // 0..1
  final List<DocStat> docs;
  final List<double> minutes30; // oldest -> today
  const StatsData(
      this.streak, this.totalCards, this.accuracy, this.docs, this.minutes30);
}

final statsProvider = FutureProvider.autoDispose<StatsData>((ref) async {
  final isar = ref.watch(isarProvider);
  final now = DateTime.now();
  DateTime day(DateTime x) => DateTime(x.year, x.month, x.day);

  final sessions = await isar.studySessions.where().findAll();
  final results = await isar.quizResults.where().findAll();

  // Streak: consecutive active days ending today (or yesterday).
  final days = sessions.map((s) => day(s.startedAt)).toSet();
  var cursor = day(now);
  if (!days.contains(cursor)) {
    cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
  }
  var streak = 0;
  while (days.contains(cursor)) {
    streak++;
    cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
  }

  final totalCards = sessions.fold<int>(0, (a, s) => a + s.cardsReviewed);
  final correct = results.fold<int>(0, (a, r) => a + r.correct);
  final total = results.fold<int>(0, (a, r) => a + r.total);

  final minutes = List<double>.filled(30, 0);
  for (final s in sessions) {
    final diff = day(now).difference(day(s.startedAt)).inDays;
    if (diff >= 0 && diff < 30) minutes[29 - diff] += s.minutesStudied;
  }

  final docs = <DocStat>[];
  for (final d in await isar.documents.where().sortByCreatedAtDesc().findAll()) {
    final cards =
        await isar.flashcards.filter().documentIdEqualTo(d.id).count();
    final mastered = await isar.flashcards
        .filter()
        .documentIdEqualTo(d.id)
        .and()
        .repetitionsGreaterThan(2)
        .count();
    final rs = results.where((r) => r.documentId == d.id);
    final t = rs.fold<int>(0, (a, r) => a + r.total);
    final c = rs.fold<int>(0, (a, r) => a + r.correct);
    docs.add(DocStat(d, cards, mastered, t == 0 ? null : c / t));
  }

  return StatsData(
      streak, totalCards, total == 0 ? null : correct / total, docs, minutes);
});
