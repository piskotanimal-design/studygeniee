import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme.dart';
import 'features/home/home_shell.dart';
import 'features/onboarding/onboarding_screen.dart';
import 'providers/providers.dart';

class StudyGenieApp extends ConsumerWidget {
  const StudyGenieApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final onboarded = ref.watch(settingsProvider).onboarded;
    return MaterialApp(
      title: 'StudyGenie',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      home: onboarded ? const HomeShell() : const OnboardingScreen(),
    );
  }
}
