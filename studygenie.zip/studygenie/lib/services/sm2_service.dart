import '../data/models/flashcard.dart';

/// SM-2 spaced repetition.
/// Quality: Again = 0, Hard = 3, Good = 4, Easy = 5.
class Sm2Service {
  static const again = 0;
  static const hard = 3;
  static const good = 4;
  static const easy = 5;

  static void review(Flashcard c, int quality) {
    final now = DateTime.now();

    if (quality < 3) {
      c.repetitions = 0;
      c.interval = 1;
      c.nextReview = now; // due again right away (re-queued this session)
    } else {
      if (c.repetitions == 0) {
        c.interval = 1;
      } else if (c.repetitions == 1) {
        c.interval = 6;
      } else {
        c.interval = (c.interval * c.easeFactor).round();
      }
      c.repetitions += 1;
      c.nextReview = DateTime(now.year, now.month, now.day + c.interval);
    }

    final q = quality.toDouble();
    c.easeFactor += 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02);
    if (c.easeFactor < 1.3) c.easeFactor = 1.3;
    c.lastReviewed = now;
  }
}
