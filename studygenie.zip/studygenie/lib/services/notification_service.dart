import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../data/settings_store.dart';

class NotificationService {
  final _plugin = FlutterLocalNotificationsPlugin();

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'study_reminders',
      'Study reminders',
      channelDescription: 'Reminds you to study at your chosen time',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
    ),
  );

  Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      tz.setLocalLocation(
          tz.getLocation(await FlutterTimezone.getLocalTimezone()));
    } catch (_) {
      // falls back to UTC; reminders may be off by the UTC offset
    }
    await _plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ));
  }

  tz.TZDateTime _next(int weekday, int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var d = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    while (d.weekday != weekday || d.isBefore(now)) {
      d = tz.TZDateTime(tz.local, d.year, d.month, d.day + 1, hour, minute);
    }
    return d;
  }

  /// Cancels all reminders and re-creates them from current settings.
  Future<void> reschedule(SettingsStore s) async {
    for (var d = 1; d <= 7; d++) {
      await _plugin.cancel(100 + d);
    }
    if (!s.reminderEnabled) return;

    for (final day in s.reminderDays) {
      await _plugin.zonedSchedule(
        100 + day,
        'Time to study 📚',
        'A few flashcards today keeps your streak alive.',
        _next(day, s.reminderHour, s.reminderMinute),
        _details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      );
    }
  }
}
