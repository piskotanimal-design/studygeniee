import 'package:isar/isar.dart';

import '../data/models/provider_usage.dart';

class UsageCounterService {
  final Isar isar;
  UsageCounterService(this.isar);

  DateTime get _today {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  Future<int> countToday(String provider) async {
    final u = await isar.providerUsages
        .filter()
        .providerNameEqualTo(provider)
        .and()
        .dateEqualTo(_today)
        .findFirst();
    return u?.requestCount ?? 0;
  }

  Future<void> increment(String provider) async {
    await isar.writeTxn(() async {
      var u = await isar.providerUsages
          .filter()
          .providerNameEqualTo(provider)
          .and()
          .dateEqualTo(_today)
          .findFirst();
      u ??= ProviderUsage()
        ..providerName = provider
        ..date = _today;
      u.requestCount++;
      await isar.providerUsages.put(u);
    });
  }
}
