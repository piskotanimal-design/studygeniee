import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path/path.dart' as p;
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:xml/xml.dart';

import '../core/errors.dart';

/// All extraction runs on-device. Nothing is uploaded.
class FileExtractionService {
  static const supported = ['pdf', 'docx', 'txt', 'pptx', 'png', 'jpg', 'jpeg'];

  Future<String> extract(String path,
      {void Function(double progress)? onProgress}) async {
    final ext = p.extension(path).replaceFirst('.', '').toLowerCase();
    onProgress?.call(0.05);
    try {
      final text = switch (ext) {
        'txt' => await _txt(path),
        'pdf' => await _pdf(path, onProgress),
        'docx' => await _docx(path),
        'pptx' => await _pptx(path),
        'png' || 'jpg' || 'jpeg' => await _image(path),
        _ => throw const ExtractionException(
            'This file type is not supported. Use PDF, DOCX, PPTX, TXT, PNG or JPG.'),
      };
      onProgress?.call(1);
      final cleaned = text.replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
      if (cleaned.isEmpty) {
        throw const ExtractionException(
            'No readable text was found. If this is a scan, try a clearer photo, or paste the text instead.');
      }
      return cleaned;
    } on ExtractionException {
      rethrow;
    } catch (_) {
      throw const ExtractionException(
          'This file could not be read. It may be damaged or protected. You can paste the text instead.');
    }
  }

  Future<String> _txt(String path) async =>
      utf8.decode(await File(path).readAsBytes(), allowMalformed: true);

  Future<String> _pdf(String path, void Function(double)? onProgress) async {
    final doc = PdfDocument(inputBytes: await File(path).readAsBytes());
    try {
      final extractor = PdfTextExtractor(doc);
      final n = doc.pages.count;
      final buf = StringBuffer();
      for (var i = 0; i < n; i++) {
        buf.writeln(extractor.extractText(startPageIndex: i, endPageIndex: i));
        onProgress?.call(0.05 + 0.9 * (i + 1) / n);
        await Future<void>.delayed(Duration.zero); // let the UI repaint
      }
      return buf.toString();
    } finally {
      doc.dispose();
    }
  }

  Future<String> _docx(String path) async {
    final archive = ZipDecoder().decodeBytes(await File(path).readAsBytes());
    final f = archive.findFile('word/document.xml');
    if (f == null) throw const ExtractionException('Invalid DOCX file.');
    final xml = XmlDocument.parse(utf8.decode(f.content as List<int>));
    return xml
        .findAllElements('w:p')
        .map((para) => para.findAllElements('w:t').map((t) => t.innerText).join())
        .where((s) => s.trim().isNotEmpty)
        .join('\n');
  }

  Future<String> _pptx(String path) async {
    final archive = ZipDecoder().decodeBytes(await File(path).readAsBytes());
    final re = RegExp(r'^ppt/slides/slide(\d+)\.xml$');
    final slides = archive.files.where((f) => re.hasMatch(f.name)).toList()
      ..sort((a, b) => int.parse(re.firstMatch(a.name)!.group(1)!)
          .compareTo(int.parse(re.firstMatch(b.name)!.group(1)!)));
    if (slides.isEmpty) throw const ExtractionException('Invalid PPTX file.');

    final buf = StringBuffer();
    for (var i = 0; i < slides.length; i++) {
      final xml = XmlDocument.parse(utf8.decode(slides[i].content as List<int>));
      buf.writeln('Slide ${i + 1}');
      for (final para in xml.findAllElements('a:p')) {
        final line = para.findAllElements('a:t').map((t) => t.innerText).join();
        if (line.trim().isNotEmpty) buf.writeln(line);
      }
      buf.writeln();
    }
    return buf.toString();
  }

  Future<String> _image(String path) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(path));
      return result.text;
    } finally {
      await recognizer.close();
    }
  }
}
