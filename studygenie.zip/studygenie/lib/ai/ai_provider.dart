import 'package:dio/dio.dart';

import '../core/errors.dart';
import '../data/models/study_material.dart';
import 'json_parser.dart';
import 'prompt_builder.dart';

abstract class AiProvider {
  String get name;

  Future<StudyMaterial> generate(String text, {String difficulty});

  /// Throws [AiException] if the key/endpoint does not work.
  Future<void> testKey();
}

AiException mapDioError(DioException e) {
  final code = e.response?.statusCode;
  final body = e.response?.data?.toString().toLowerCase() ?? '';
  if (code == 429) {
    return const AiException(AiFailure.quota,
        'This provider\'s free quota is used up for now.');
  }
  if (code == 401 || code == 403 || body.contains('api key not valid')) {
    return const AiException(
        AiFailure.badKey, 'The API key was rejected. Check it in Settings.');
  }
  if (code != null) {
    return AiException(
        AiFailure.other, 'The AI service returned an error ($code).');
  }
  return const AiException(
      AiFailure.network, 'Could not reach the AI service. Check your internet.');
}

/// Shared retry + error handling. Subclasses only implement [callModel].
abstract class BaseAiProvider implements AiProvider {
  final String apiKey;
  final Dio dio;

  BaseAiProvider(this.apiKey, {Dio? dio})
      : dio = dio ??
            Dio(BaseOptions(
              connectTimeout: const Duration(seconds: 20),
              receiveTimeout: const Duration(seconds: 120),
            ));

  /// Sends the prompt and returns the model's raw text answer.
  Future<String> callModel(String system, String user, {bool ping = false});

  Future<StudyMaterial> _attempt(String user) async {
    final raw = await callModel(PromptBuilder.system, user);
    return JsonParser.parse(raw);
  }

  @override
  Future<StudyMaterial> generate(String text,
      {String difficulty = 'medium'}) async {
    try {
      try {
        return await _attempt(PromptBuilder.user(text, difficulty));
      } on FormatException {
        // Retry once with a stricter prompt.
        return await _attempt(PromptBuilder.strict(text, difficulty));
      }
    } on FormatException {
      throw AiException(AiFailure.badResponse,
          '$name returned an answer that could not be read.');
    } on DioException catch (e) {
      throw mapDioError(e);
    } on AiException {
      rethrow;
    } catch (_) {
      throw AiException(AiFailure.other, '$name failed unexpectedly.');
    }
  }

  @override
  Future<void> testKey() async {
    try {
      await callModel('Reply with the word ok.', 'ok', ping: true);
    } on DioException catch (e) {
      throw mapDioError(e);
    } on FormatException {
      // Reached the service and authenticated; empty body is fine for a ping.
    }
  }
}
