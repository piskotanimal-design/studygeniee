import '../core/constants.dart';

class PromptBuilder {
  static const system = '''
You are a study-material generator for students of any grade level.
Return ONLY one valid JSON object, with no markdown, no code fences and no text outside the JSON.
Use exactly this schema:
{
  "summary": "string, 3-5 sentences",
  "flashcards": [{"front": "string", "back": "string"}],
  "qa_pairs": [{"question": "string", "answer": "string", "difficulty": "easy|medium|hard"}],
  "mcq_quiz": [{"question": "string", "options": ["string","string","string","string"], "correct_index": 0, "explanation": "string"}]
}
Rules: base everything ONLY on the provided material; make exactly 4 options per MCQ with one correct answer; correct_index is the 0-based index of the correct option; vary the position of the correct answer; keep language simple and clear.''';

  static String _trim(String text) => text.length > Limits.maxInputChars
      ? text.substring(0, Limits.maxInputChars)
      : text;

  static String user(String text, String difficulty) => '''
Create study material from the text below.
Target difficulty: $difficulty.
Produce about 10 flashcards, 10 Q&A pairs (mix of easy/medium/hard) and 8 multiple-choice questions. Produce fewer if the material is short.

STUDY MATERIAL:
"""
${_trim(text)}
"""''';

  static String strict(String text, String difficulty) => '''
${user(text, difficulty)}

IMPORTANT: Your previous answer was not valid JSON. Respond with ONLY the raw JSON object. Start with { and end with }. No explanations, no markdown.''';
}
