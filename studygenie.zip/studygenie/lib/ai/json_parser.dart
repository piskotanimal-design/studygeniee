import 'dart:convert';

import '../data/models/study_material.dart';

class JsonParser {
  /// Extracts the outermost JSON object from [raw] and validates it.
  /// Throws [FormatException] if it cannot be used.
  static StudyMaterial parse(String raw) {
    final start = raw.indexOf('{');
    final end = raw.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw const FormatException('No JSON object found');
    }
    final decoded = jsonDecode(raw.substring(start, end + 1));
    if (decoded is! Map) throw const FormatException('Not a JSON object');
    return StudyMaterial.fromJson(Map<String, dynamic>.from(decoded));
  }
}
