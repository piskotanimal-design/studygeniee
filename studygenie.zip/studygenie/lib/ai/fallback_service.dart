import '../core/constants.dart';
import '../core/errors.dart';
import '../data/models/study_material.dart';
import '../data/secure_key_store.dart';
import '../data/settings_store.dart';
import '../services/usage_counter_service.dart';
import 'ai_provider.dart';
import 'providers/cerebras_provider.dart';
import 'providers/gemini_provider.dart';
import 'providers/groq_provider.dart';
import 'providers/openrouter_provider.dart';
import 'providers/sambanova_provider.dart';

AiProvider buildProvider(String name, String key) => switch (name) {
      Providers.gemini => GeminiProvider(key),
      Providers.cerebras => CerebrasProvider(key),
      Providers.groq => GroqProvider(key),
      Providers.sambanova => SambaNovaProvider(key),
      Providers.openrouter => OpenRouterProvider(key),
      _ => throw ArgumentError('Unknown provider $name'),
    };

class GenerationResult {
  final StudyMaterial material;
  final String providerName;
  const GenerationResult(this.material, this.providerName);
}

class FallbackService {
  final SecureKeyStore keys;
  final SettingsStore settings;
  final UsageCounterService usage;
  FallbackService(this.keys, this.settings, this.usage);

  Future<GenerationResult> generate(
    String text, {
    String difficulty = 'medium',
    void Function(String provider)? onAttempt,
    void Function(String message)? onSwitch,
  }) async {
    if (text.trim().length < Limits.minInputChars) {
      throw const AiException(AiFailure.badInput,
          'There is not enough text to study from. Add more text or try a different file.');
    }

    final limit = settings.dailyLimit;
    final failures = <AiFailure>[];
    String? pending; // reason the previous provider was skipped/failed
    var withKeys = 0;

    for (final name in settings.priority) {
      final key = await keys.read(name);
      if (key == null || key.isEmpty) continue;
      withKeys++;

      if (await usage.countToday(name) >= limit) {
        failures.add(AiFailure.limit);
        pending = '$name daily limit reached';
        continue;
      }

      if (pending != null) onSwitch?.call('Switched to $name due to $pending');
      onAttempt?.call(name);

      try {
        final material =
            await buildProvider(name, key).generate(text, difficulty: difficulty);
        await usage.increment(name);
        return GenerationResult(material, name);
      } on AiException catch (e) {
        failures.add(e.kind);
        pending = '$name ${e.shortReason}';
      }
    }

    if (withKeys == 0) {
      throw const AiException(AiFailure.noKeys,
          'Add at least one free API key in Settings to generate study material.');
    }
    if (failures.every((f) => f == AiFailure.network)) {
      throw const AiException(AiFailure.network,
          'No internet connection. Connect and try again. Your saved material still works offline.');
    }
    if (failures.every((f) => f == AiFailure.quota || f == AiFailure.limit)) {
      throw const AiException(AiFailure.quota,
          'Free quota or your daily limit is used up on every provider. Raise the limit in Settings, add another key, or try again later.');
    }
    throw const AiException(AiFailure.allFailed,
        'All providers failed. Check your keys in Settings and try again.');
  }
}
