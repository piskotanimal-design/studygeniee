import 'package:dio/dio.dart';

import '../../core/constants.dart';
import '../ai_provider.dart';

class GeminiProvider extends BaseAiProvider {
  GeminiProvider(super.apiKey, {super.dio});

  @override
  String get name => Providers.gemini;

  static const _str = {'type': 'STRING'};

  static final Map<String, dynamic> _schema = {
    'type': 'OBJECT',
    'properties': {
      'summary': _str,
      'flashcards': {
        'type': 'ARRAY',
        'items': {
          'type': 'OBJECT',
          'properties': {'front': _str, 'back': _str},
          'required': ['front', 'back'],
        },
      },
      'qa_pairs': {
        'type': 'ARRAY',
        'items': {
          'type': 'OBJECT',
          'properties': {
            'question': _str,
            'answer': _str,
            'difficulty': _str, // easy | medium | hard
          },
          'required': ['question', 'answer', 'difficulty'],
        },
      },
      'mcq_quiz': {
        'type': 'ARRAY',
        'items': {
          'type': 'OBJECT',
          'properties': {
            'question': _str,
            'options': {'type': 'ARRAY', 'items': _str},
            'correct_index': {'type': 'INTEGER'},
            'explanation': _str,
          },
          'required': ['question', 'options', 'correct_index', 'explanation'],
        },
      },
    },
    'required': ['summary', 'flashcards', 'qa_pairs', 'mcq_quiz'],
  };

  @override
  Future<String> callModel(String system, String user,
      {bool ping = false}) async {
    final res = await dio.post(
      'https://generativelanguage.googleapis.com/v1beta/models/${ModelNames.gemini}:generateContent',
      options: Options(headers: {
        'x-goog-api-key': apiKey,
        'Content-Type': 'application/json',
      }),
      data: {
        'systemInstruction': {
          'parts': [
            {'text': system}
          ]
        },
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': user}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.4,
          if (!ping) 'responseMimeType': 'application/json',
          if (!ping) 'responseSchema': _schema,
        },
      },
    );
    final cands = res.data['candidates'];
    if (cands is! List || cands.isEmpty) {
      throw const FormatException('No candidates in response');
    }
    final parts = cands.first['content']?['parts'];
    if (parts is! List) throw const FormatException('No parts in response');
    return parts.map((p) => p['text'] ?? '').join();
  }
}
