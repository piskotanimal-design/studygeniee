import 'package:dio/dio.dart';

import '../ai_provider.dart';

/// Base for any OpenAI-compatible chat-completions endpoint.
abstract class OpenAiCompatibleProvider extends BaseAiProvider {
  OpenAiCompatibleProvider(super.apiKey, {super.dio});

  String get endpoint;
  String get model;
  Map<String, dynamic> get extraBody => const {};
  Map<String, String> get extraHeaders => const {};

  @override
  Future<String> callModel(String system, String user,
      {bool ping = false}) async {
    final res = await dio.post(
      endpoint,
      options: Options(headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
        ...extraHeaders,
      }),
      data: {
        'model': model,
        'messages': [
          {'role': 'system', 'content': system},
          {'role': 'user', 'content': user},
        ],
        'temperature': 0.4,
        if (ping) 'max_tokens': 32,
        if (!ping) ...extraBody,
      },
    );
    final choices = res.data['choices'];
    if (choices is! List || choices.isEmpty) {
      throw const FormatException('No choices in response');
    }
    return (choices.first['message']['content'] ?? '').toString();
  }
}
