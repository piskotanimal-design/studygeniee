import '../../core/constants.dart';
import 'openai_compatible_provider.dart';

class OpenRouterProvider extends OpenAiCompatibleProvider {
  OpenRouterProvider(super.apiKey, {super.dio});

  @override
  String get name => Providers.openrouter;
  @override
  String get endpoint => 'https://openrouter.ai/api/v1/chat/completions';
  @override
  String get model => ModelNames.openrouter;
  @override
  Map<String, String> get extraHeaders => const {'X-Title': 'StudyGenie'};
}
