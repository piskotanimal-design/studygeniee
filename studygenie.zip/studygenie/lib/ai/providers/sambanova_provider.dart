import '../../core/constants.dart';
import 'openai_compatible_provider.dart';

class SambaNovaProvider extends OpenAiCompatibleProvider {
  SambaNovaProvider(super.apiKey, {super.dio});

  @override
  String get name => Providers.sambanova;
  @override
  String get endpoint => 'https://api.sambanova.ai/v1/chat/completions';
  @override
  String get model => ModelNames.sambanova;
}
