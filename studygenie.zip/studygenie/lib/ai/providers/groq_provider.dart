import '../../core/constants.dart';
import 'openai_compatible_provider.dart';

class GroqProvider extends OpenAiCompatibleProvider {
  GroqProvider(super.apiKey, {super.dio});

  @override
  String get name => Providers.groq;
  @override
  String get endpoint => 'https://api.groq.com/openai/v1/chat/completions';
  @override
  String get model => ModelNames.groq;
  @override
  Map<String, dynamic> get extraBody => const {
        'response_format': {'type': 'json_object'},
      };
}
