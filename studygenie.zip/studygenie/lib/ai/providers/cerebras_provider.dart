import '../../core/constants.dart';
import 'openai_compatible_provider.dart';

class CerebrasProvider extends OpenAiCompatibleProvider {
  CerebrasProvider(super.apiKey, {super.dio});

  @override
  String get name => Providers.cerebras;
  @override
  String get endpoint => 'https://api.cerebras.ai/v1/chat/completions';
  @override
  String get model => ModelNames.cerebras;
  @override
  Map<String, dynamic> get extraBody => const {
        'response_format': {'type': 'json_object'},
      };
}
