import 'package:isar/isar.dart';

part 'flashcard.g.dart';

@collection
class Flashcard {
  Id id = Isar.autoIncrement;

  @Index()
  late int documentId;
  late int materialId;

  late String front;
  late String back;

  // SM-2 state
  double easeFactor = 2.5;
  int interval = 0; // days
  int repetitions = 0;

  @Index()
  late DateTime nextReview;
  DateTime? lastReviewed;
}
