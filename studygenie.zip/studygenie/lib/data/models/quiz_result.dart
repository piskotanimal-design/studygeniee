import 'package:isar/isar.dart';

part 'quiz_result.g.dart';

@collection
class QuizResult {
  Id id = Isar.autoIncrement;

  @Index()
  late int documentId;
  late int correct;
  late int total;
  late DateTime takenAt;
}
