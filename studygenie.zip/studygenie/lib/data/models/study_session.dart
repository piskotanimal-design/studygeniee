import 'package:isar/isar.dart';

part 'study_session.g.dart';

@collection
class StudySession {
  Id id = Isar.autoIncrement;
  late DateTime startedAt;
  int minutesStudied = 0;
  int cardsReviewed = 0;
  int quizzesTaken = 0;
}
