import 'study_material_entry.dart';

class FlashcardDto {
  final String front;
  final String back;
  const FlashcardDto(this.front, this.back);
}

/// Provider-agnostic result of one AI generation.
class StudyMaterial {
  final String summary;
  final List<FlashcardDto> flashcards;
  final List<QaPair> qaPairs;
  final List<Mcq> mcqs;

  const StudyMaterial({
    required this.summary,
    required this.flashcards,
    required this.qaPairs,
    required this.mcqs,
  });

  static String _s(dynamic v) => v == null ? '' : v.toString().trim();
  static List<dynamic> _list(dynamic v) => v is List ? v : const [];

  /// Defensive parse: skips malformed items, throws [FormatException]
  /// only if nothing usable came back.
  factory StudyMaterial.fromJson(Map<String, dynamic> j) {
    final cards = <FlashcardDto>[];
    for (final e in _list(j['flashcards'])) {
      if (e is! Map) continue;
      final f = _s(e['front']);
      final b = _s(e['back']);
      if (f.isNotEmpty && b.isNotEmpty) cards.add(FlashcardDto(f, b));
    }

    final qas = <QaPair>[];
    for (final e in _list(j['qa_pairs'])) {
      if (e is! Map) continue;
      final q = _s(e['question']);
      final a = _s(e['answer']);
      var d = _s(e['difficulty']).toLowerCase();
      if (!const ['easy', 'medium', 'hard'].contains(d)) d = 'medium';
      if (q.isNotEmpty && a.isNotEmpty) {
        qas.add(QaPair()
          ..question = q
          ..answer = a
          ..difficulty = d);
      }
    }

    final mcqs = <Mcq>[];
    for (final e in _list(j['mcq_quiz'])) {
      if (e is! Map) continue;
      final q = _s(e['question']);
      final opts =
          _list(e['options']).map(_s).where((s) => s.isNotEmpty).toList();
      final raw = e['correct_index'];
      final idx = raw is num ? raw.toInt() : (int.tryParse(_s(raw)) ?? -1);
      if (q.isEmpty || opts.length < 2 || idx < 0 || idx >= opts.length) {
        continue;
      }
      mcqs.add(Mcq()
        ..question = q
        ..options = opts
        ..correctIndex = idx
        ..explanation = _s(e['explanation']));
    }

    if (cards.isEmpty && qas.isEmpty && mcqs.isEmpty) {
      throw const FormatException('No usable study items in response');
    }
    return StudyMaterial(
      summary: _s(j['summary']),
      flashcards: cards,
      qaPairs: qas,
      mcqs: mcqs,
    );
  }
}
