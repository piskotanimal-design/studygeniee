import 'package:isar/isar.dart';

part 'provider_usage.g.dart';

@collection
class ProviderUsage {
  Id id = Isar.autoIncrement;

  @Index()
  late String providerName;
  late DateTime date; // midnight of the day
  int requestCount = 0;
}
