import 'package:isar/isar.dart';

part 'document.g.dart';

@collection
class Document {
  Id id = Isar.autoIncrement;
  late String title;
  late String subject;
  late String rawText;
  late String filePath;
  late DateTime createdAt;

  /// Denormalised count of Q&A pairs in the latest generation (for the dashboard).
  int qaCount = 0;
}
