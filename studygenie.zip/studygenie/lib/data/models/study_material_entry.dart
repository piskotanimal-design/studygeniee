import 'package:isar/isar.dart';

part 'study_material_entry.g.dart';

@Collection(accessor: 'materials')
class StudyMaterialEntry {
  Id id = Isar.autoIncrement;

  @Index()
  late int documentId;

  late String summary;
  List<QaPair> qaPairs = [];
  List<Mcq> mcqs = [];
  late DateTime generatedAt;
  late String providerUsed;
}

@embedded
class QaPair {
  String question = '';
  String answer = '';
  String difficulty = 'medium';
}

@embedded
class Mcq {
  String question = '';
  List<String> options = [];
  int correctIndex = 0;
  String explanation = '';
}
