import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// API keys live ONLY here (Android Keystore-backed storage).
class SecureKeyStore {
  final _s = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  String _k(String provider) => 'api_key_$provider';

  Future<String?> read(String provider) => _s.read(key: _k(provider));

  Future<void> write(String provider, String key) =>
      _s.write(key: _k(provider), value: key.trim());

  Future<void> delete(String provider) => _s.delete(key: _k(provider));
}
