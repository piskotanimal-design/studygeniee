import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants.dart';

/// Non-secret settings (order, limit, reminders). Keys are NOT stored here.
class SettingsStore {
  final SharedPreferences p;
  SettingsStore(this.p);

  List<String> get priority {
    final saved = p.getStringList('priority') ?? const [];
    final order = saved.where(Providers.defaultOrder.contains).toList();
    for (final n in Providers.defaultOrder) {
      if (!order.contains(n)) order.add(n);
    }
    return order;
  }

  Future<void> setPriority(List<String> v) => p.setStringList('priority', v);

  int get dailyLimit => p.getInt('daily_limit') ?? 3;
  Future<void> setDailyLimit(int v) => p.setInt('daily_limit', v);

  bool get reminderEnabled => p.getBool('reminder_enabled') ?? false;
  Future<void> setReminderEnabled(bool v) => p.setBool('reminder_enabled', v);

  /// 1 = Monday ... 7 = Sunday
  Set<int> get reminderDays =>
      (p.getStringList('reminder_days') ?? const ['1', '2', '3', '4', '5'])
          .map(int.parse)
          .toSet();
  Future<void> setReminderDays(Set<int> v) =>
      p.setStringList('reminder_days', v.map((e) => '$e').toList());

  int get reminderHour => p.getInt('reminder_hour') ?? 18;
  int get reminderMinute => p.getInt('reminder_minute') ?? 0;
  Future<void> setReminderTime(int h, int m) async {
    await p.setInt('reminder_hour', h);
    await p.setInt('reminder_minute', m);
  }

  bool get onboarded => p.getBool('onboarded') ?? false;
  Future<void> setOnboarded() => p.setBool('onboarded', true);
}
