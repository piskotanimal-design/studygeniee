import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';

import 'models/document.dart';
import 'models/flashcard.dart';
import 'models/provider_usage.dart';
import 'models/quiz_result.dart';
import 'models/study_material.dart';
import 'models/study_material_entry.dart';
import 'models/study_session.dart';

class IsarService {
  static Future<Isar> open() async {
    final dir = await getApplicationDocumentsDirectory();
    return Isar.open(
      [
        DocumentSchema,
        StudyMaterialEntrySchema,
        FlashcardSchema,
        QuizResultSchema,
        ProviderUsageSchema,
        StudySessionSchema,
      ],
      directory: dir.path,
    );
  }
}

extension IsarHelpers on Isar {
  /// Saves a generation (entry + flashcards) and updates the document's Q&A count.
  Future<void> saveGeneration(
      Document doc, StudyMaterial m, String provider) async {
    await writeTxn(() async {
      final entry = StudyMaterialEntry()
        ..documentId = doc.id
        ..summary = m.summary
        ..qaPairs = m.qaPairs
        ..mcqs = m.mcqs
        ..generatedAt = DateTime.now()
        ..providerUsed = provider;
      final entryId = await materials.put(entry);

      final now = DateTime.now();
      final cards = m.flashcards
          .map((f) => Flashcard()
            ..documentId = doc.id
            ..materialId = entryId
            ..front = f.front
            ..back = f.back
            ..nextReview = now)
          .toList();
      await flashcards.putAll(cards);

      doc.qaCount = m.qaPairs.length;
      await documents.put(doc);
    });
  }

  Future<void> deleteDocumentCascade(int docId) async {
    await writeTxn(() async {
      await flashcards.filter().documentIdEqualTo(docId).deleteAll();
      await materials.filter().documentIdEqualTo(docId).deleteAll();
      await quizResults.filter().documentIdEqualTo(docId).deleteAll();
      await documents.delete(docId);
    });
  }

  Future<void> logSession({
    required DateTime startedAt,
    required Duration elapsed,
    int cards = 0,
    int quizzes = 0,
  }) async {
    final minutes = (elapsed.inSeconds / 60).ceil().clamp(1, 600);
    await writeTxn(() async {
      await studySessions.put(StudySession()
        ..startedAt = startedAt
        ..minutesStudied = minutes
        ..cardsReviewed = cards
        ..quizzesTaken = quizzes);
    });
  }

  Future<StudyMaterialEntry?> latestMaterial(int docId) => materials
      .filter()
      .documentIdEqualTo(docId)
      .sortByGeneratedAtDesc()
      .findFirst();
}
